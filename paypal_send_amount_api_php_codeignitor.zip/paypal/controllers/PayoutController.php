<?php

header('Access-Control-Allow-Origin: *');  
require __DIR__  .'/paypal/vendor/autoload.php';

class PayoutController extends CI_Controller{
	
# Construct Function
 public function __construct()
 {
      parent::__construct();
      $this->load->model('Global_model');
		  $this->load->library('form_validation');
      $this->load->library('session');
      $this->load->helper('url');
     
  		$data=shopifyData();
    	$this->load->library('Shopify' , $data);
 }

// Get Commission Data
 public function GetCommissionData()
 {
   # Get All Commission Data
  if ($_GET['cId'] != '') {
    # code...
    $cId = $_GET['cId'];

    $commission_details = $this->db->select('*')->where('id',$cId)->get('affiliate_commission')->row();

    $shop_name = $commission_details->shop;

    $commission = $commission_details->total_commission;

    $otherdb = $this->load->database('otherdb', TRUE);
    $email = $otherdb->select('paypal_email')->where('domain',$shop_name)->get('shopify_stores')->row()->paypal_email;

    $transfer_pay = $this->BulkPayment($email,$shop_name,$commission);
    if ($transfer_pay) {
      # Save And Update Status
      $this->db->set(['payout_batch_id'=>$transfer_pay,'status'=>1])->where('id',$cId)->update('affiliate_commission');
      $response = array(
                          'code'=>200,
                          'response'=>'Success',
                          'msg'=>'Payment Transfered SuccessFullly.'
                        );
      echo json_encode($response);
    } else {
      # Return With Error
      $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Payment Transfer Fail'
                        );
      echo json_encode($response);

    }
    


  } else {
    # if No Commission ID Fopund
    // echo "<script>alert('Invalid URI Access');</script>";
    $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'invalid URI Access'
                        );
      echo json_encode($response);
  }
  

 }


#Do Bulk Payment
 public function BulkPayment()
 {
   # code...

  $apiContext = new \PayPal\Rest\ApiContext(
            new \PayPal\Auth\OAuthTokenCredential(
                'ATQmQEM2pzO6zyPMO0i3opLRgnR6hysiTIHgN0mmcaHXHW50E0bFgYXxy4Tp8DaCrDSINGdYlG1Vvn5X',     // ClientID
                'EMVg0FIbjv6P6GJ4kbKgIrZlDD5S-vow9FpnCb0zQb-jXy725xrSfNFl9XWZ3guanmmPj68XlzfOk7oZ'      // ClientSecret
            )
        );


  $payouts = new \PayPal\Api\Payout();
  $senderBatchHeader = new \PayPal\Api\PayoutSenderBatchHeader();
// ### NOTE:
// You can prevent duplicate batches from being processed. If you specify a `sender_batch_id` that was used in the last 30 days, the batch will not be processed. For items, you can specify a `sender_item_id`. If the value for the `sender_item_id` is a duplicate of a payout item that was processed in the last 30 days, the item will not be processed.
// #### Batch Header Instance
$senderBatchHeader->setSenderBatchId(uniqid())
    ->setEmailSubject("You have a Payout!");
// #### Sender Item
// Please note that if you are using single payout with sync mode, you can only pass one Item in the request
$senderItem = new \PayPal\Api\PayoutItem();
$senderItem->setRecipientType('Email')
    ->setNote('Thanks for your Support!')
    ->setReceiver('yahya.dummy@gmail.com')
    ->setSenderItemId("2014031400023")
    ->setAmount(new \PayPal\Api\Currency('{
                        "value":"2.0",
                        "currency":"USD"
                    }'));
$payouts->setSenderBatchHeader($senderBatchHeader)
    ->addItem($senderItem);
// For Sample Purposes Only.
$request = clone $payouts;
// ### Create Payout
try {
    $output = $payouts->createSynchronous($apiContext);
} catch (Exception $ex) {
    // NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
    // ResultPrinter::printError("Created Single Synchronous Payout", "Payout", null, $request, $ex);
    // echo "<pre>";
    // print_r($ex);
    // exit(1);

  return false;
}
// NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
 // ResultPrinter::printResult("Created Single Synchronous Payout", "Payout", $output->getBatchHeader()->getPayoutBatchId(), $request, $output);
// return $output;
// echo "<pre>";
  // print_r($output);

return $output->getBatchHeader()->getPayoutBatchId();
 }


 // Transfer All Commission
 public function TransferAllCommission()
 {
   # Get Month And Year
    if ($_GET['cDataId'] != '') {
      # Commission Data Id Not found Get Year And Month
      $commissions_data = $this->db->select('*')->where('id',$_GET['cDataId'])->get('genrated_commission')->row();

      $month = $commissions_data->month;
      $year = $commissions_data->year;


      // Get All Commisiion Of That Whose Commission is Greater Than $10
      $commissions = $this->db->select('*')->where('month',$month)->where('year',$year)->where('total_commission','>=',10)->get('affiliate_commission')->result();

      // Loop In ForEach
      foreach ($commissions as $commission) {
        # 
        $shop_name = $commission->shop;

        $commission_amount = $commission->total_commission;

        $otherdb = $this->load->database('otherdb', TRUE);
        $email = $otherdb->select('paypal_email')->where('domain',$shop_name)->get('shopify_stores')->row()->paypal_email;

        $transfer_pay = $this->BulkPayment($email,$shop_name,$commission_amount);
      }

      $response = array(
                          'code'=>200,
                          'response'=>'Success',
                          'msg'=>'Payment Transfer Success'
                        );
      echo json_encode($response);


    } else {
      # Return With No month and year found Error
      $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Payment Transfer Fail'
                        );
      echo json_encode($response);
    }
  
 }
  
      
}

