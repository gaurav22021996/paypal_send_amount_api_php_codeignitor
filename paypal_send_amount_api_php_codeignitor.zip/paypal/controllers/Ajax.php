<?php
require __DIR__.'/domparser/simple_html_dom.php';
class Ajax extends CI_Controller{
	  public function __construct()
    {
        parent::__construct();
        $this->load->model('Global_model');
  		$this->load->library('form_validation');
        $this->load->library('session');
  		//$data=shopifyData();
    	//$this->load->library('Shopify' , $data);


    }


    public function LoginCheck()
    {
       $access_token=$_POST['access_token'];
       if($access_token!=''){
        $sql="select * from shopify_stores where token='".$access_token."' limit 0,1";
        $query=$this->db->query($sql);
        if($query->num_rows()>0){
            $result=$query->row();
            echo '{"code":"200","storeData":'.json_encode($result).'}';

        }
        else
        {
            echo '{"code":"100"}';

        }

       }else
       {
            echo '{"code":"100"}';
       }
      
    }



    public function updateRules()
    {
        //print_r($_POST);
        if($_POST['shop']!='')
        {
            $shop=$_POST['shop'];
            $accessData=getShop_accessToken_byShop($_POST['shop']);
            if($accessData['ACCESS_TOKEN']!='')
            {
                $this->load->library('Shopify' , $accessData);
                $this->writeScript($shop);

               // $themes=  $this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/themes.json'],TRUE);
               // print_r($themes);
               // if(count($themes)>0)
                //{
                     //foreach ($themes->themes as $theme)
                     //{
                        //if($theme->role=="main")
                        //{
                            //$theme->id;
                            //$this->getThemeliquid($shop, $theme->id);
                        //}
                        
                     //}
                //}
               

            }
            else
            {
                 echo '{"code":"404"}';
            }

        }
        else
        {
            echo '{"code":"404"}';
        }
       
    }

    public function writeScript($shop)
    {
      $scriptUrl=$shop."-script.js";
      $p = $this->scriptJs();
      $a = fopen($scriptUrl, 'w');
      fwrite($a, $p);
      fclose($a);
      chmod($scriptUrl, 0777);
      $found=0;

      $datas=array("script_tag"=>array(
          "event"=>"onload",
          "src"=> base_url().$scriptUrl
       
      ));
      // echo json_encode($datas);
      
      //$this->shopify->call(['METHOD' => 'DELETE', 'URL' =>'/admin/script_tags/18527813675.json'],TRUE);
       $dattt=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/script_tags.json'],TRUE);
       //print_r($dattt);
       //exit;
       if(isset($dattt->script_tags))
       {
          if(count($dattt->script_tags)>0)
          {
            foreach($dattt->script_tags as $script)
            {
                $urldata=explode('/', $script->src);
                $endurl= end($urldata);
              if($endurl==$scriptUrl)
              {
                $found ++;
              }
              
            }
          }

       }
       if($found==0)
       {
        $this->shopify->call(['METHOD' => 'POST', 'URL' =>'/admin/script_tags.json','DATA'=>$datas],TRUE);
       }

    }



   

    public function getThemeliquid($shop, $themeId)
    {   
        $accessData=getShop_accessToken_byShop($shop);
         if($accessData['ACCESS_TOKEN']!='')
            {
                $this->load->library('Shopify' , $accessData);
               

                $themePage=  $this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/themes/'.$themeId.'/assets.json?asset[key]=layout/theme.liquid&theme_id='.$themeId],TRUE);
                //print_r($themePage);
                //exit;
                if(count($themePage)>0)
                {
                    if($themePage->asset->value!='')
                    {
                        /************ Save product page *******/
                        $this->Global_model->checkStoreThemes($themePage->asset->value,$themeId);
                        $scriptUrl=$shop."-script.js";
                        $p = $this->scriptJs();
                        $a = fopen($scriptUrl, 'w');
                        fwrite($a, $p);
                        fclose($a);
                        chmod($scriptUrl, 0755);
                        $found=0;

                        $datas=array("script_tag"=>array(
                            "event"=>"onload",
                            "src"=> base_url().$scriptUrl
                         
                        ));
                        // echo json_encode($datas);
                         $dattt=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/script_tags.json'],TRUE);
                         
                         if(isset($dattt->script_tags))
                         {
                            if(count($dattt->script_tags)>0)
                            {
                              foreach($dattt->script_tags as $script)
                              {
                                  $urldata=explode('/', $script->src);
                                  $endurl= end($urldata);
                                if($endurl==$scriptUrl)
                                {
                                  $found ++;
                                }
                                
                              }
                            }

                         }
                         if($found==0)
                         {
                          $this->shopify->call(['METHOD' => 'POST', 'URL' =>'/admin/script_tags.json','DATA'=>$datas],TRUE);
                         }

                    }
                }
            }
            else
            {
                 echo '{"code":"404"}';
            }

        
    }




   
    public function updateChatFuelSettings()
    {

        //print_r($_POST);
        if($_POST['checkbox']!='' && $_POST['chatbotid']!='')
        { 
            $html = new simple_html_dom();
            $html_string=$_POST['checkbox'];
            $html->load($html_string);
            $datas=$html->find('div',0);
            if(isset($datas->attr))
            {
                $attribute=$datas->attr;
                if(isset($attribute['messenger_app_id']) && isset($attribute['page_id']))
                {
                    if($_POST['chatbotid']!='')
                    {
                        $urlex=explode('/',$_POST['chatbotid']);
                        if(isset($urlex[5]))
                        {
                           $checkoboxCode= $this->generateCheckBoxCode($attribute);
                           $shopThemedata= $this->Global_model->getShopThemeId($_POST['shop']);
                            if(count($shopThemedata)>0)
                            {
                                $shopThemedata->theme_id;
                                $shopThemedata->product_page_old;
                                 $htmlarray=array('asset'=>array(
                                'key'=>'templates/product.liquid',
                                'value'=>$shopThemedata->product_page_old.$checkoboxCode
                                ));
                                 $apidata=array( 'API_KEY' => $this->config->item('shopify_api_key'),
                                    'API_SECRET' => $this->config->item('shopify_secret'),
                                    'SHOP_DOMAIN' => $_POST['shop'],
                                    'ACCESS_TOKEN' => $_POST['access_token']);
                                 print_r($apidata);
                                 $this->load->library('Shopify' , $apidata);
                                $themes=  $this->shopify->call(['METHOD' => 'PUT', 'URL' =>'/admin/themes/'.$shopThemedata->theme_id.'/assets.json',
                                    'DATA'=>$htmlarray],TRUE);
                               print_r($themes);
                            }
                            else
                            {
                                  echo '{"code":"100","msg":"Product Page Not Found."}';  
                            }
                             /*$themes=  $this->shopify->call(['METHOD' => 'PUT', 'URL' =>'/admin/themes/'.$shopThemeId.'/assets.json'],TRUE);
                                $htmlarray=array('asset'=>array(
                                'key'=>'templates/product.liquid',
                                'value'=>$data['prdpage'].$custom_html
                                ));
                                */
                                

                        }
                        else
                        {
                            echo '{"code":"100","msg":"Invalid ChatFuel Bot URL"}';  
                        }
                    }
                    else
                    {
                        echo '{"code":"100","msg":"Invalid Checkbox Code"}';  
                    }

                }
                else
                {
                  echo '{"code":"100","msg":"Invalid Checkbox Code"}';  
                }
            }
            else
            {
                 echo '{"code":"100","msg":"Invalid Checkbox Code"}';  
            }
        }
        else
        {
            echo '{"code":"100", "msg":"Invalid Data"}';
        }
        
      
        //$html->load($html_string);
        //$datas=$html->find('div',0);
        //$attribute=$datas->attr;

    }

   

    public function generateCheckBoxCode($attribute){

      $custom_html='

        <input type="hidden" value="{{shop.domain}}" id="shop_name">
        <input type="hidden" value="" id="crttoken">
            <script
  src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>
<script>
  var urlredirect="{{shop.url}}";

 function testMyfunction()
  {
        
         var cartForm1 =document.querySelector("form[action='."'".'/cart/add'."'".']"); 
        
     $.ajax({
            type: "POST",
            url: "/cart/add.js",
            data:$("form[action='."'".'/cart/add'."'".']").serialize(),
            dataType:"JSON",
            success:function(dd)
            {
          

                $.ajax({
                type: "GET",
                url: "/cart.js",
                dataType:"JSON",
                success:function(cartdata)
                {
                    $("#crttoken").val(cartdata["token"]);
                    window.location.href=urlredirect+"/cart"; 
                     window.confirmOptIn(); 
                },
                 });


            },
    });
        
   
  }

</script>
        
<script> 
var cartForm =document.querySelector("form[action='."'".'/cart/add'."'".']");
  var buttonn=cartForm.querySelector('."'".'button[type="submit"]'."'".');
  buttonn.setAttribute("type", "button");
  buttonn.setAttribute("onclick", "testMyfunction();");
 // console.log(buttonn);
  //console.log();
  var prnt=buttonn.parentElement;
var parent=prnt.parentElement;
  //console.log(parent);
    var mydiv = document.createElement("div");
  mydiv.setAttribute("id", "FbDDDiv1");
  parent.appendChild(mydiv);
  var el = document.querySelector("#FbDDDiv1");
  el.innerHTML += '."'".'<div  class="fb-messenger-checkbox" origin="" page_id="'.$attribute['page_id'].'" messenger_app_id="'.$attribute['messenger_app_id'].'" user_ref="" prechecked="true" allow_login="true" size="large"></div>'."'".';
window.fbMessengerPlugins = window.fbMessengerPlugins || {
    init: function() {
        FB.init({
            appId: "'.$attribute['messenger_app_id'].'",
            xfbml: true,
            version: "v2.6"
        });
    },
    callable: []
};
window.fbMessengerPlugins.callable.push(function() {
    var ruuid, fbPluginElements = document.querySelectorAll(".fb-messenger-checkbox[page_id='."'".$attribute['page_id']."'".']");
    if (fbPluginElements) {
        for (i = 0; i < fbPluginElements.length; i++) {
            ruuid = "cf_" + (new Array(16).join().replace(/(.|$)/g, function() {
                return ((Math.random() * 36) | 0).toString(36)[Math.random() < .5 ? "toString" : "toUpperCase"]();
            }));
            fbPluginElements[i].setAttribute("user_ref", ruuid);
            fbPluginElements[i].setAttribute("origin", window.location.href);
            window.confirmOptIn = function() {
            var shopify_cust_id= $("#shopify_cust_id").val();
            var first_name= $("#first_name").val();
            var last_name= $("#last_name").val();
            var storeName=$("#shop_name").val();
            var cartdata=$("#crttoken").val(); 
            console.log(JSON.stringify(cartdata));
            window.refBlock = "cartFuel|"+ruuid+"|"+cartdata+"|"+storeName+"|"+shopify_cust_id+"|"+first_name+"|"+last_name;
                FB.AppEvents.logEvent("MessengerCheckboxUserConfirmation", null, {
                    app_id: "'.$attribute['messenger_app_id'].'",
                    page_id: "'.$attribute['page_id'].'",
                    ref: window.refBlock,
                    user_ref: ruuid
                });
          


             
            };
        }
    }
});
window.fbAsyncInit = window.fbAsyncInit || function() {
    window.fbMessengerPlugins.callable.forEach(function(item) {
        item();
    });
    window.fbMessengerPlugins.init();
};
setTimeout(function() {
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, "script", "facebook-jssdk"));
}, 0);

</script>
';  
    return $custom_html;
    }


    function scriptJs(){
      return  $tag="  
  var count1=0;  
  function counter(cart){
    $.each(cart.items,function(index,item1){
      var pro_price1=item1.original_price;
      if(pro_price1==0){
        count1=count1 + 1;
      }
    });
    return count1;
  }

  function StopLoadingRedirect(response){
    $('.loading').hide();
    var url = window.location.href;
    if(url.split('/')[3]=='cart'){
      document.location.reload(true);
    }else{
      window.location.href=urlredirect+'/cart';
    }
  }  

  function UpdateFullCart(){
    jQuery.getJSON('/cart.js', function(cart){
      var cart_count = counter(cart);
      if(cart_count>0){
        sort_cart_items(cart);
      }else{
        getLeastProduct();
      }
    });

  }
  function sort_cart_items(cart_items){
    var items=cart_items.items;
    function compare(a,b) {
      if (moneyFormat(a.price) < moneyFormat(b.price))
        return -1;
      if (moneyFormat(a.price) > moneyFormat(b.price))
        return 1;
      return 0;
    }

    items.sort(compare);
    free_to_paid(items);
  }

  function free_to_paid(cart){
    var pro_price;
    var remove_free='';
    var add_paid_two='';
    var handle='';
    var cart_handle='';
    count1=counter(cart);
    var count2=1;
    
    $.each(cart,function(index,item){

      pro_price=moneyFormat(item.price);
      if(pro_price==0){

        remove_free += '&updates['+item.variant_id+']=0';
        handle=item.handle;
        cart_handle=handle.replace('-free','');

        $.ajax({
          type: 'GET',
          url: '/products/'+cart_handle+'.js',
          dataType:'JSON',
          success:function(products)
          {
            var varID=products.variants[0].id;
            var ItemQuant;
            var founddata=FindAlreadyProduct(varID,item.quantity)
            add_paid_two += '&updates[' + varID + ']=' + founddata;
            if(count2 == count1){
              var updateCart=remove_free+add_paid_two;
              UpdateCart(updateCart);
            }
            count2++;
          },
          error:function(error){
            StopLoadingRedirect();
          }
        });

      }
    });
    
    function FindAlreadyProduct(varID,quant){
      var ItemQuant;
      cart.find(function(element) {
        if(element.id==varID){
          ItemQuant=quant+element.quantity;
        }
      });
      return ItemQuant;
    }
    
  }



  function UpdateCart(updateCart){
    var removeCart=updateCart.replace('&',''); 
    $.ajax({
      type:'POST',
      url:'/cart/update.js',
      data:removeCart,
      dataType:'json',
      success:function(response){
        getLeastProduct();
      }
    });
  }


  function moneyFormat(price_check){
    var fomatted_price;
    if(price_check>0){
      var new_price = price_check.toString().split('');
      var money_price ='';
      var before_format='';
      var after_format='';
      var loop_limit= new_price.length;

      for(var i=0;i<=loop_limit-3;i++){
        before_format= before_format+new_price[i];
      }

      for(var j=loop_limit-2;j<=loop_limit-1;j++){
        after_format= after_format+new_price[j];
      }
      fomatted_price= before_format+'.'+after_format;
    }else{
      fomatted_price='0';
    }
    return parseFloat(fomatted_price);
  }

  function getLeastProduct(urlredirect){
    jQuery.getJSON('/cart.js', function(cart){
      var cart_count = cart.item_count;
      var quant=0;
      var free_pro=0;
      if(cart_count>=3){
        $.each(cart.items,function(index,cart_item){
          quant+=cart_item.quantity;
          if(cart_item.price==0){
            free_pro+=cart_item.quantity;
          }
        });
        least_price_product(cart,quant,free_pro);
      }else{
        //goto cart page
        StopLoadingRedirect();
      }
    });
  }   


  function least_price_product(cartItems,quant){
    var sum=0;
    var cart_item_price;
    var exempted_product=Math.floor(quant/3);
    var productArray=[];
    var x;

    $.each(cartItems.items,function(index,cartItem){
      cart_item_price = moneyFormat(cartItem.price);
      sum += parseInt(cartItem.quantity);

      for(x=0;x<cartItem.quantity;x++){
        var productQuant=[];  

        productQuant.push(cartItem.handle);
        productQuant.push(cart_item_price);
        productQuant.push(cartItem.id);
        productQuant.push(cartItem.quantity);
        productArray.push(productQuant);

      }
    });

    var items=productArray;
    function compare(a,b) {
      if (a[1] < b[1])
        return -1;
      if (a[1] > b[1])
        return 1;
      return 0;
    }

    items.sort(compare);

    var j;
    var updateArray=[];
    for(j=0;j<exempted_product;j++){
      var singleProduct=[];
      singleProduct.push(items[j][0]);
      singleProduct.push(items[j][2]);
      singleProduct.push(items[j][3]);
      updateArray.push(singleProduct);
    }

    var groups = {};
    for (var i = 0; i < updateArray.length; i++) {
      var groupName = updateArray[i][0];
      if (!groups[groupName]) {
        groups[groupName] = [];
      }
      var GroupArray=[];
      GroupArray.push(updateArray[i][0]);
      GroupArray.push(updateArray[i][1]);
      GroupArray.push(updateArray[i][2]);
      groups[groupName].push(GroupArray);
    }

    var groups = $.map(groups, function(value) {
      return [value];
    });
    var UpdateString='';
    var count = 0;
    var ArrayLenght=groups.length;

    for(var g=0; g<ArrayLenght;g++){

      var cart_handle=groups[g][0][0]+'-free';
      $.ajax({
        type:'GET',
        url:'/products/'+cart_handle,
        dataType:'json',
        success:function(response){
          var varID = response.product.variants[0].id;
          var proLength=groups[count].length;
          var proLength1=groups[count][0][2]-groups[count].length;
          if(count==0){
            UpdateString += 'updates[' + varID + ']=' + proLength+'&updates[' + groups[count][0][1] + ']=' + proLength1;
          }else{
            UpdateString += '&updates[' + varID + ']=' + proLength+'&updates[' + groups[count][0][1] + ']=' + proLength1;
          }
          if(ArrayLenght-1==count)
          {
            AddDiscountProduct(UpdateString)
          }
          count++;
        }
      });

    }

    function AddDiscountProduct(UpdateString){
      $.ajax({
        type:'POST',
        url:'/cart/update.js',
        data:UpdateString,
        dataType:'json',
        success:function(response){
          StopLoadingRedirect(response);
        }
      });
    }
  }

jQuery.getJSON('/cart.js', function(cart){
  $.each(cart.items,function(index,cart_item){
    if(cart_item.price==0){
        $('.congrats_text').show();
    }
  });
});


";

    }
		
}

