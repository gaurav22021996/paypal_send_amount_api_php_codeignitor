<?php
 header('Access-Control-Allow-Origin: *');  
class Checkout extends CI_Controller{
	  public function __construct()
    {
        parent::__construct();
        $this->load->model('Global_model');
  		  $this->load->library('form_validation');
    }

    // To Add Product In Draft Order
    function getSelectedProduct()
    {

      $shop_name = "testbeargrip.myshopify.com";
      $apiconfig= getShop_accessToken_byShop($shop_name);
      $this->load->library('Shopify' , $apiconfig);

      $product_details['send_draft_order_data'] = $this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products/'.$_GET['product_id'].'.json'], TRUE);

    
      $this->load->view('choose-product', $product_details);


    }

    // Create Draft Order
    public function create_draft_orders()
    {


      if (!empty($_POST)) {
        
        $variant_id = $this->input->post('variant_id');
        $quantity = $this->input->post('quantity');
        $ref_shop = $this->input->post('ref_shop');

        // Draft order Details
        $htmlarray = array('draft_order'=>array(
                        'line_items'=>array(
                                        array(
                                            "variant_id" => $variant_id,
                                            "quantity"=> $quantity
                                          )
                                        ),
                        'tags'=>$ref_shop,

                    ));

        // Create Draft Order
        $shop_name = "testbeargrip.myshopify.com";
        $apiconfig= getShop_accessToken_byShop($shop_name);
        $this->load->library('Shopify' , $apiconfig);

        $draft_order =  $this->shopify->call(['METHOD' => 'POST', 'URL' =>'/admin/draft_orders.json','DATA'=>$htmlarray],TRUE); 

        $draft_order_details = $draft_order->draft_order;

        //Make Draft Order Save In App
        $data = array(
                        'shop_name'=>$ref_shop,
                        'product_id'=>$draft_order_details->line_items[0]->product_id,
                        'variant_id'=>$draft_order_details->line_items[0]->variant_id,
                        'amount'=>$draft_order_details->subtotal_price,
                        'draft_order_id'=>$draft_order_details->id,
                      );
        $this->db->insert('affiliate_orders',$data);
        // exit;
        // Return On Payment checkout Page
        $invoice_url = $draft_order_details->invoice_url;
        echo "<script>window.location.href = '".$invoice_url."';</script>";
        // header("location :".$invoice_url);

      }


    }
    
}

