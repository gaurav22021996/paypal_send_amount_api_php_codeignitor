<?php
header('Access-Control-Allow-Origin: *');  

class Home extends CI_Controller{
#Construct Function 
  public function __construct()
  {
      parent::__construct();
      $this->load->model('Global_model');
		  $this->load->library('form_validation');
      $this->load->library('session');
      if($this->session->userdata('access_token')=='')
      {
       
      }
  }

# Dashboard of Admin
  public function Dashboard()
  {
    // Shop Domain 
    $shop=$data['shop']=$_GET['shop'];

    if($_GET['shop']!=''){
      // Access Token
      $access_token= getShop_accessToken_byShop($shop);
      $data['access_token']=$access_token['ACCESS_TOKEN'];

      // Api Call
      $apiconfig= getShop_accessToken_byShop($shop);
      // $this->load->library('Shopify' , $apiconfig);
      // $orders=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products.json'],TRUE);

      // $data['products'] = $orders->products[0];
      $data['shop'] = $shop;
      
      // List of affilate user
      $data['affilates'] = $this->get_shop_data();

      // Return TO Dashboard
      $this->load->load_admin('app/dashboard',$data);

    }else{
      redirect('Auth/Install_login');
    }
  }

#Get Single Product
  public function getSingleProduct($productId=NULL)
  {

        $shop_name = 'testbeargrip.myshopify.com'; //testbeargrip.myshopify.com
      
        
        $apiconfig= getShop_accessToken_byShop($shop_name);
        $this->load->library('Shopify' , $apiconfig);

       $product=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products/'.$productId.'.json'],TRUE);
       echo json_encode($product);
  }

# Return Shop 
  public function get_shop_data()
  {
    // Instense of other Database
    $otherdb = $this->load->database('otherdb', TRUE);
    
    $select_affilates = $otherdb->select('*')->get('shopify_stores');

    $affilates = $select_affilates->result();

    // Return List Of User Installed Affilate App
    return $affilates;
  }

# Get Product Json 
  public function ProductJson()
  {

    // Shop Name
    $shop_name = 'testbeargrip.myshopify.com';

    $apiconfig= getShop_accessToken_byShop($shop_name);
    $this->load->library('Shopify' , $apiconfig);

    $product=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products.json'],TRUE);
    
    echo json_encode($product);
  }

# Affilate Order
  public function AffilateOrder()
  {
    # Get All Affilate Order
    $orders = $this->db->select('*')->get('affiliate_orders')->result();
    $data['orders'] = $orders;

    $this->load->load_admin('app/orders',$data);
  }

#Change Status Of Order
  public function changeStatus()
  {
    # Get Order Id And Status Number
    if ($_POST['orderId'] != '' && $_POST['status'] != '') {
      # Update Here
      $orderId = $_POST['orderId'];
      $status = $_POST['status'];
      $this->db->set('status',$status)->where('draft_order_id',$orderId)->update('affiliate_orders');
      $response = array(
                          'code'=>200,
                          'response'=>'Success',
                          'msg'=>'Status Updated Successfully.'
                        );
      echo json_encode($response);

    }else{
      #Return Fail Response
      $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Something Went Wrong Please Try Again.'
                        );
      echo json_encode($response);
    }
  }

#Affiliate commission 
  public function affiliateCommission()
   {
     # Get List Of Affiliate users with Commision
     $commisions = $this->db->select('*')->get('genrated_commission');
     $commisions_data = $commisions->result();

     
     $data['commissions'] = $commisions_data;

     $this->load->load_admin('app/commissions',$data);
   } 

# Genrate Commisiion
   public function genrateCommission()
   {
     # Get Month And Year
    if ($_POST['month'] != '' && $_POST['year'] != '') {
      # If month and year is not blank
      $current_month = date('m');
      $current_year = date('Y');

      $month = $_POST['month'];
      $year = $_POST['year'];
      if ($year == $current_year) {
        # if same year
        if ($month < $current_month) {
          # Valid

          #check for already genrated Commission
          $is_gen = $this->db->select('*')->where('month',$month)->where('year',$year)->get('affiliate_commission');
          if ($is_gen->num_rows() > 0) {
            # Alrady Genrated
            $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Already genrated Commission For Selected Month.'
                        );
            echo json_encode($response);
          } else {
            # Not Genrated
            $shop_names  = $this->db->select('shop_name')->where("DATE_FORMAT(created_at,'%Y-%m')", $year.'-'.$month)->where('status',1)->group_by('shop_name')->get('affiliate_orders')->result();
          
         #store Data
            $total_commission = 0;
         foreach ($shop_names as $shop_name) {
             # code...
            $sum_amount = $this->db->select_sum('amount')->where('shop_name',$shop_name->shop_name)->where('status',1)->get('affiliate_orders')->row();
            if (isset($sum_amount)) {
              # code...
              $data = array(
                              'shop'=>$shop_name->shop_name,
                              'month'=>$month,
                              'year'=>$year,
                              'total_spend'=>$sum_amount->amount,
                              'total_commission'=>($sum_amount->amount) * 0.10,
                            );
              $this->db->insert('affiliate_commission',$data);
              $total_commission = $total_commission + ($sum_amount->amount * 0.10);
              // array_push($shopCommissions, ['shop'=>$shop_name->shop_name,'amount'=>$sum_amount->amount]);
            }

           }

            // Update Table Of genrated Commission
            $data_com = array(
                                'month'=>$month,
                                'year'=>$year,
                                'total_commission'=>$total_commission,
                                'total_shops'=>count($shop_names)
                              );
            $this->db->insert('genrated_commission',$data_com);

            $response = array(
                          'code'=>200,
                          'response'=>'Success',
                          'msg'=>'Commission genrated Successfully.'
                        );
            echo json_encode($response);
          }

        } else {
          # Invalid
           $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Invalid Month! Please Enter Previous Month.'
                        );
            echo json_encode($response);

        }
        
      } elseif($year < $current_year) {
        # Previous Year (Valid Only if month is Janury)
        if ($current_month == 01 && $month == 12) {
          # valid
            $query  = $this->db->select('*')->where("MONTH(created_at)", $month)->where("YEAR('created_at')",$year)->get('affiliate_orders')->result();
            print_r($query);
            exit;
        } else {
          # Invalid
            $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Invalid Month! Please Enter Month And Year Properly.'
                        );
            echo json_encode($response);
        }
        
      }else{
        #Next Year
        // Invalid Data
          $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'PLease  Enter Valid Year (Only Current Or Previous).'
                        );
          echo json_encode($response);
      }
      
    }else{
      #return response With Fail
      $response = array(
                          'code'=>202,
                          'response'=>'Fail',
                          'msg'=>'Insufficient data Please Enter Month And Year.'
                        );
      echo json_encode($response);
    }
   }


   public function viewCommisions()
   {
     # check For Month And Year
     if ($_GET['month'] != '' && $_GET['year']!='') {
       # Get All Commisiions
      $commissions = $this->db->select('*')->where('month',$_GET['month'])->where('year',$_GET['year'])->get('affiliate_commission');
        $all_data = $commissions->result();

        $data['commissions'] = $all_data;
        $this->load->load_admin('app/viewCommission',$data);
     } else {
       # code...
      echo "Invalid Data";
     }
     
   }
}

